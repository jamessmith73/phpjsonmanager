<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=utf-8');
die(file_get_contents('employeeData.json'));
?>
