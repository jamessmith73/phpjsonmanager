<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<?php
/*
  "EMPLOYEE_ID": 100,
        "FIRST_NAME": "Madhusudhan",
        "LAST_NAME": "Rao",
        "EMAIL": "SKING",
        "PHONE_NUMBER": "515.123.4567",
        "HIRE_DATE": "1987-06-17",
        "SALARY": 24000,
        "DEPARTMENT_ID": 90
 */
$message = '';
$error = '';
$filename = "employeeData.json";
if(isset($_POST["submit"]))
{
        $fullname = $_POST['FIRST_NAME']." ".$_POST['LAST_NAME'];
        if(file_exists($filename))
        {
            $current_data = file_get_contents($filename);
            $tempArray = json_decode($current_data, true);

            array_push($tempArray['Employees'],
                                                array('EMPLOYEE_ID' => $_POST['EMPLOYEE_ID'],
                                                'FIRST_NAME' => $_POST["FIRST_NAME"],
                                                'LAST_NAME' => $_POST["LAST_NAME"],
                                                 'EMAIL'  =>     $_POST["EMAIL"],
                                                'PHONE_NUMBER'  =>     $_POST["PHONE_NUMBER"],
                                                'HIRE_DATE'  =>     $_POST["HIRE_DATE"],
                                                'SALARY'  =>     $_POST["SALARY"],
                                                'DEPARTMENT_ID'  =>     $_POST["DEPARTMENT_ID"])
                    );
            if(file_put_contents($filename, json_encode($tempArray)))
            {
                $message = "<label class='text-success'>File Appended Success fully for $fullname <a href='empjsonGET.php'>View Json</a> </p>";
            }

            /*
            $extra = array(
                'EMPLOYEE_ID'               =>     $_POST['EMPLOYEE_ID'],
                'FIRST_NAME'          =>     $_POST["FIRST_NAME"],
                'LAST_NAME'     =>     $_POST["LAST_NAME"],
                'EMAIL'  =>     $_POST["EMAIL"],
                'PHONE_NUMBER'  =>     $_POST["PHONE_NUMBER"],
                'HIRE_DATE'  =>     $_POST["HIRE_DATE"],
                'SALARY'  =>     $_POST["SALARY"],
                'DEPARTMENT_ID'  =>     $_POST["DEPARTMENT_ID"]
            );
            $array_data[] = $extra;
            $final_data = json_encode($array_data);
            if(file_put_contents($filename, $final_data))
            {
                $message = "<label class='text-success'>File Appended Success fully for $fullname <a href='empjsonGET.php'>View Json</a> </p>";
            }
            */
        }
        else
        {
            $error = 'JSON File not exits';
        }

}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple JSON Manager</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
<br />
<div class="container" style="width:500px;">
    <h3 align="">Append Data to JSON File</h3><br />
    <form method="post">
        <?php
        if(isset($error))
        {
            echo $error;
        }
        ?>
        <br />
        <label>EMPLOYEE_ID</label>
        <input type="text" name="EMPLOYEE_ID" value="21288" class="form-control" /><br />
        <label>FIRST_NAME</label>
        <input type="text" name="FIRST_NAME" value="Madhusudhan" class="form-control" /><br />
        <label>LAST_NAME</label>
        <input type="text" name="LAST_NAME" value="Rao" class="form-control" /><br />
        <label>EMAIL</label>
        <input type="text" name="EMAIL" value="softwarearchitect73" class="form-control" />@gmail.com<br />
        <label>PHONE_NUMBER</label>
        <input type="text" name="PHONE_NUMBER" value="98864484XX" class="form-control" /><br />
        <label>HIRE_DATE</label>
        <input type="text" name="HIRE_DATE" value="2007-12-27" class="form-control" /><br />
        <label>SALARY</label>
        <input type="text" name="SALARY" value="1000" class="form-control" /><br />
        <label>DEPARTMENT_ID</label>
        <input type="text" name="DEPARTMENT_ID" value="99" class="form-control" /><br />

        <input type="submit" name="submit" value="Append" class="btn btn-info" /><br />
        <?php
        if(isset($message))
        {
            echo $message;
        }
        ?>
    </form>
</div>
<br />
</body>
</html>